# grupo_4_drinkHouse

Drink House
Nuestro sitio web tiene por objetivo brindar un servicio de venta de bebidas alcohólicas con envío a domicilio para empresas y personas particulares +18. La idea de nuestro eCommerce surge en el año 2022 cuando sus cuatro fundadores, provenientes de diferentes ámbitos laborales, se conocen en un curso de programación realizado en Digital House. 
Nuestros valores se basan en:
Calidad, búsqueda constante de la excelencia de todas nuestras acciones.
Responsabilidad, con nuestros clientes y proveedores.
Flexibilidad, capacidad para adaptarnos a las diversas circunstancias sociales y económicas del entorno.

El wireframe del proyecto se encuenta en la carpeta "wireframe.pdf" dentro del repositorio.

El logo del proyecto se encuenta en la carpeta Images con el nombre "Drink_House_SVG.svg" dentro del repositorio.  

Paginas referentes:
1) https://www.appbar.com.ar/ Por lo simple e intuitivo de la interfaz.
2) https://salimosfuerte.com/ Se ajustó con la estética de la página pricipal.
3) https://www.fullescabio.com/ Por la similitud con MercadoShops.
4) https://www.craftsociety.com.ar/ Por la  la manera que presenta los productos individualmente.
5) https://www.yopongoelhielo.com/es/ Por la forma de agregar el producto al carrito de compras.

Integrantes:
Emerson Leonardo Chapeta.
Ariel Pagani
Actualmente trabajando con traslados de pasajeros, 42 años. Siempre me gusto la informatica y me he vinculado con lo relacionado a IT, actualmente busco un cambio economico en mi vida. 
Ignacio Oteiza
24 años, estudiante, aficionado a los videojuegos. Me gusta aprender sobre tecnologias innovadoras y todo aquello que me genera intriga y me presenta un desafio.
Alexis Ariel Bello
Arquitecto, 36 años, padre de dos hijos, hincha de Boca. Como profesional me apasiona la dinámica de resolver problemas concretos en obra y poder descubrir, junto al cliente, el diseño para sus proyectos. Me siento cómodo trabajando en equipos interdiciplinarios, donde considero que se aprende mucho desde el aporte de cada integrante.
