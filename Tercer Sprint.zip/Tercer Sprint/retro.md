
Utilizando como base la dinámica de estrella de mar hicimos una retrospectiva de como venimos trabajando en el proyecto integrador.

•	Comenzar a hacer: Como primer paso nos pusimos de acuerdo en cómo pretendíamos en que debería verse nuestro sitio. Se realizaron propuestas y llegamos a una idea en la que todos estuvimos de acuerdo. También definimos el funcionamiento y la organización de sitio. 
En este punto no tuvimos mayores inconvenientes y supimos resolverlo de manera rápida y ágil.
•	Mas de: Llegado el momento de ponernos a codear nos dividimos las tareas para poder llegar a entregar todo. A medida que cada integrante del grupo avanzaba con su parte se fue metiendo en otras tareas y terminamos haciendo casi todas las tareas de manera individual. Lo positivo de que haya ocurrido de esta manera fue que se aportaron muchas ideas que hicieron crecer el proyecto y podíamos imaginarnos más cosas para mejorar. Lo negativo es que nos costó poder llegar con todos los puntos del entregable.

•	Seguir haciendo: La comunicación del equipo es buena y cuando surgen ideas podemos plantearlas libremente y analizar si se implementa o no. En este punto nos costó hacer zoom out y ver el proyecto integral, nos concentramos en resolver problemas específicos que nos demoraron en el entregable. Consideramos que a mejorar deberíamos poder dividirnos las tareas y delegarnos el trabajo para poder cumplir con todos los puntos del sprint.

•	Menos de: A medida que íbamos trabajando en el código se nos dificultó hacer un corte en los detalles perdiendo la homogeneidad del sitio. Es decir, sucedió que algunas partes de la página tienen mucho detalle y otras no tanto. Esto hizo que tomáramos la decisión de intentar entregar todas las partes del entregable con un mismo nivel de detalle y no querer llegar a hacer más de lo que se nos pedía.

•	Dejar de hacer: Decidimos como equipo dejar de meternos tanto en los detalles de alguna parte del entregable e intentar a llegar con todos los puntos del entregable. Las ideas que sumen valor al sitio se verán llegado el momento. Intentamos resolver de lo general a lo particular del proyecto sin perder de vista la idea principal del ecommerce.
